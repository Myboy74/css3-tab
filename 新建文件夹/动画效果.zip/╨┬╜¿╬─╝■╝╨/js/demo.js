$(function () {
    var y0=0;
    var y1=0;
    var num = 0;
    var index = 0;
    function move (index){
        num=0;
        $("#footer li").removeClass("red");
        $("#footer li:eq("+index+")").addClass("red");
        $("#top li").addClass("select selected");
        $("#top li>div img").addClass("first").removeClass("one");
        $("#top li:eq(" + index + ")").addClass("select").removeClass("selected");
        $("#top li:eq(" + index + ")>div img").removeClass("one");
    }
    $("#footer li").on("click", function () {
        // y0 = e.originalEvent.changedTouches[0].pageY;
        index = $(this).index();
        move(index);
    });
    // $("#footer li").on("touchend", function () {
    //     y1 = e.originalEvent.changedTouches[0].pageY;
    //     index = $(this).index();
    //     move(index);
    //     if (y1 > y0 + 50) {
    //         console.log("下");
    //         index = $(this).index();
    //         move(index);
    //
    //     }
    //     if (y1 < y0 - 50){
    //         console.log("上")
    //         index = $(this).index();
    //         move(index);
    //     }
    // })

    $(".title").on("click", function () {
        // $("#top li>div img").addClass("first").removeClass("one");
        var len = $("#top li:eq(" + index + ")>div img").length-1;
        if (num < len) {
            num++;
            $("#top li:eq(" + index + ")>div img:eq("+num+")").addClass("one");

        }else{
            if(index>$("#footer li").length){
                index=0;
            }
            index++;
            move(index);


        }

    })
})